package error;
public class ErrorLexico extends Error{     
    @Override
    public String showErrores(){
       return "Error " + getCodigo() + ": " + getDescripcion() + " En el archivo " + getNombreArchivo() + " || Linea: " + getNumLinea();
    }
}

