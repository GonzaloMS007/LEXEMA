package error;
import java.util.ArrayList;
import java.util.List;
public abstract class Error {
    private int codigo;
    private String descripcion;
    private int numLinea;
    private String nombreArchivo;
    private static final List<Error> errores = new ArrayList();
    
    public abstract String showErrores();
    
    public static final void addError(Error error){
        Error.errores.add(error);
    }
    public static final void limpiarErrores(){
        Error.errores.clear();
    }
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descipcion) {
        this.descripcion = descipcion;
    }
    public int getNumLinea() {
        return numLinea;
    }
    public void setNumLinea(int numLinea) {
        this.numLinea = numLinea;
    }
    public String getNombreArchivo() {
        return nombreArchivo;
    }
    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }
    public static List<Error> getErros() {
        return errores;
    }   
}

