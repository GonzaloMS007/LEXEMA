package tablaDeSimbolos;
import java.util.ArrayList;
import java.util.List;
public class Simbolos {
    private String nombre;    
private static final List<Simbolos> tablaDeSimbolos = new ArrayList();
    public String getNombre() {
        return nombre;
    }
    public void setNome(String nombre) {
        this.nombre = nombre;
    }
    public static void addSimbolo(Simbolos simbolo) {
        if (!Simbolos.tablaDeSimbolos.contains(simbolo))
            Simbolos.tablaDeSimbolos.add(simbolo);
    }
    public static List<Simbolos> getTabelaDeSimbolos() {
        return tablaDeSimbolos;
    }
    @Override
    public String toString(){
        return this.getNombre();
    }
    @Override
    public boolean equals(Object obj){
        Simbolos s = (Simbolos) obj;
        return s.getNombre().equals(this.nombre);
    }
}

